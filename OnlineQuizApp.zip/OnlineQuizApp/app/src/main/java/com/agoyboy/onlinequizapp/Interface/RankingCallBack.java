package com.agoyboy.onlinequizapp.Interface;

public interface RankingCallBack<T> {

    void callBack(T ranking);

}
