package com.agoyboy.onlinequizapp.Common;

import com.agoyboy.onlinequizapp.Model.Question;
import com.agoyboy.onlinequizapp.Model.User;

import java.util.ArrayList;
import java.util.List;

public class Common {

    public static  String CategoryId,categoryName;
    public static User currentUser;
    public static List<Question> questionList = new ArrayList<>();
}
